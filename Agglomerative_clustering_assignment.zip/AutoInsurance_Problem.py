'''
# # Clustering

# Problem Statement

# The average retention rate in the insurance industry is 84%, with the 
# top-performing agencies in the 93%-95% range. 
# Retaining customers is all about the long-term relationship you build.
# Offer a discount on the client's current policy will ensure he/she buys a 
# new product or renews the current policy.
# Studying clients' purchasing behavior to figure out which types of products 
# they're most likely to buy is very essential. 

# Insurance company wants to analyze their customer's behaviour to 
# device offers to increase customer loyalty.


# CRISP-ML(Q) process model describes six phases:
# 
# 1. Business and Data Understanding
# 2. Data Preparation
# 3. Model Building
# 4. Model Evaluation
# 5. Deployment
# 6. Monitoring and Maintenance
'''

# Objective(s): Maximize the Sales 
# Constraints: Minimize the Customer Retention


'''Success Criteria'''

# Business Success Criteria: Increase the Sales by 10% to 12% by targeting
# cross-selling opportunities for current customers.

# ML Success Criteria: Achieve a Silhouette coefficient of at least 0.6

# Economic Success Criteria: The insurance company will see an increase in 
# revenues by at least 8%



'''
# Steps to Consider:

Load the Data
Perform EDA and derive insights
Perform Data Preprocessing (steps as appropriate)
Implement Clustering (Hierarchical)
Evaluate the Model - perform tuning by altering hyperparameters - (Silhouette coefficient)
Cluster the Data using the best model (based on the metrics evaluated)
Label the clusters

'''
import numpy as np #numerical calculations
import pandas as pd #data manipulation
import matplotlib.pyplot as plt #data visulization
import seaborn as sns ##data visulization
from dython.nominal import associations #find correlations
from sklearn.preprocessing import LabelEncoder #ordinal data
from sklearn.preprocessing import OneHotEncoder #noimal data
from sklearn.preprocessing import MinMaxScaler
from scipy.cluster.hierarchy import linkage, dendrogram
from sklearn.cluster import AgglomerativeClustering 
from sklearn import metrics
from clusteval import clusteval

#import walmart data from local system
insurance = pd.read_csv(r"C:/Users/ThinkPad/Downloads/360digimg/ML/cluster/Hierarchical Clustering_Hands-on/Mod3a.Hierarchical Clustering/AutoInsurance_Problem/AutoInsurance.csv")
#info for different data types
insurance.info()
#There are total 24 columns and 9134 entries
#Out of 24 columns, 8 columns have numerical data and 16 columns have categorical data
X1 = ["Customer", "State", "Customer Lifetime Value", "Response", "Coverage", "Education", "Effective To Date", "EmploymentStatus", "Gender", "Income", "Location Code", "Marital Status", 
      "Monthly Premium Auto", "Months Since Last Claim", "Months Since Policy Inception", "Number of Open Complaints", "Number of Policies", "Policy Type", "Policy", "Renew Offer Type",
      "Sales Channel", "Total Claim Amount", "Vehicle Class", "Vehicle Size"]
X2 = ["Customer ID", "Customer state", "Cusotmer Lifetime value (CLV)", "Response from customer yes/no", "Insurance coverage", "Customer education", "Policy effective date",
      "Customer employment status", "Customer gender", "Customer income", "Customer living area", "Customer Marital Status", "monthly insurance payment", "Number of months since last claim made", 
      "months at which the insurance policy goes into effect", "Number of unresolved complaints", "Number of Policies", "Type of Policy", "Policy name", "Type of renewal offer",
      "Channel of policy sale", "Total money claimed", "car type", "size of vehicle"]
X3 = ["Categorical", "Categorical", "Numerical", "Categorical", "Categorical", "Categorical", "Categorical", "Categorical", "Categorical", "Numerical", "Categorical", "Categorical", 
      "Numerical", "Numerical", "Numerical", "Numerical", "Numerical", "Categorical", "Categorical", "Categorical", "Categorical", "Numerical", "Categorical", "Categorical"]
X4 = ["Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant",
      "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant", "Relevant"]

Data_types = pd.DataFrame({"Name of feature": X1,"Description": X2, "Data type": X3,"Relevance": X4})

#EDA

#Univariate analysis 
#First moment business decision, mean, median, mode
#First choose only numerical columns
num_col_data = insurance.select_dtypes(exclude = ['object'])
num_col_data

data_info = num_col_data.describe()
#On an average, customers have monthy income 37,600 and they pay 93.2 as monthly premium 0.2%
#The policies purchased is 3 on average
data_mode = num_col_data.mode()
#mostly people has monthly income 0 and purchased 1 policy.

cat_cols = insurance.select_dtypes(include="object")
cat_cols.drop("Customer",axis=1,inplace=True)
cat_cols.drop("Effective To Date",axis=1,inplace=True)
cat_cols.drop("State",axis=1,inplace=True)

# plot the bar chart

for col in cat_cols:
    cat_cols[col].value_counts().plot.bar(rot=0)
    plt.show()

#most of the people response no to last marketing campaign or offer
# count the number of occurrences for each category
counts = insurance["Response"].value_counts()
counts #Yes: 1308, No:7826

#Coverage type is mainly basic, then extended, then premium
'''Bachelor, College and High school customers has almost same numbers
Master and Doctor are very low that is also because they are less in number than others'''
'''Mostly are employed, then small unemployed, others are very small
Males and Females are alomost same, can drop
Most of the Customers are from suburban area and also married
mostly people buy personal insuramce auto, policy also depend upon that
Mostly people buy offer 1, then offer 2 while sales channel is mostly with agent then branch
Mostly people buy for four door with medsize'''

#Second moment business decision, std, var, min, max
data_var = num_col_data.var()
#For number of policies, std value is not very far from mean, less spread
#For monthly premioum auto, std <<<< mean, widely spread data
#Maximum number of open complaints is 5 and max no of policies purchase is 9
#Max income is 99,981 and max monthly premium is 298.

#Third moment business decision
data_skew = num_col_data.skew()
#plot histograms
num_col_data.hist(bins = 10, figsize = (20,15))
plt.show()
#data is highly positive skewed i.e. long tail on right side except fro three column
#Months since policy inception has skewness 0.02, symmetric
#Income and months since last claim has skewness 0.2, near to symmetric

#Fourth moment business decison
data_kurt = num_col_data.kurt()
'''Kurtosis >3 for CLV, monthly premium auto, no of open complaints and total claim amount shows 
Leptokurtic distribution, thin with long tails, mostly have outliers
Kurtosis <3 for Income, months since last claim, months since policy inception, no of policies
Platykurtic distribution, short tails, fewer outliers'''
#let's check with boxpplot
#For first 4 columns
num_col_data.iloc[:,:4].plot(kind = 'box', subplots = True, sharey = False, figsize = (15, 8))
plt.show()
#CLV and monthly_premium_auto has lot of outliers on upper side
num_col_data.iloc[:,4:].plot(kind = 'box', subplots = True, sharey = False, figsize = (15, 8))
plt.show()
#no of policies has outliers, it doesn't mean anything
# total claim amount have lot of outliers on upper side.


#check correlation
insurance_corr = insurance.corr()
# no strong correlation
complete_correlation= associations(insurance, filename= 'complete_correlation.png', figsize=(10,10))

df_complete_corr=complete_correlation['corr']
df_complete_corr.dropna(axis=1, how='all').dropna(axis=0, how='all').style.background_gradient(cmap='coolwarm', axis=None).set_precision(2)

#There is 1 to 1 correlation b/w policy type and policy

#also, there is 0.82 correlation b/w income and employment status


#Data cleaning
insurance.info()

#Find duplicates
duplicates = insurance.duplicated()
duplicates.sum() #no duplicates

#Find missing values
insurance.isnull().sum() #no missing values

#let's drop columns as these won't be helpful in modeling
insurance_1 = insurance.drop(["Customer", "State",  'Vehicle Class', "Education", "Coverage", 
                              'Marital Status', "Vehicle Size", "Effective To Date", "Gender", 'Income'], axis = 1)

#based on above discussion, lets drop more columns
insurance_2 = insurance_1.drop(['Policy Type',  'Months Since Policy Inception',"Policy", 'EmploymentStatus',
                                'Response', 'Number of Open Complaints', 'Renew Offer Type'], axis = 1)

insurance_2.info()
#Renew offer types improved score very much
num_col = insurance_2.select_dtypes(exclude = ['object']).columns
num_col

#dummy variable creation
#insurance_4['Response'] = insurance_4['Response'].replace({'Yes': 1, 'No': 0})
#use label encoding for vehile class as ordinal data
#labelencoder = LabelEncoder()
'''education_mapping = {
    'High School or Below': 0,
    'College': 1,
    'Bachelor': 2,
    'Master': 3,
    'Doctor': 4
}
insurance_4["Education"] = labelencoder.fit_transform(insurance_4["Education"].map(education_mapping))'''


'''vehicle_mapping = {
    'Small': 0,
    'Medsize': 1,
    'Large': 2,
}
insurance_4["Vehicle Size"] = labelencoder.fit_transform(insurance_4["Vehicle Size"].map(vehicle_mapping))
#0 is for large, 1 for mid size, 2 for small
#for coverage column
insurance_4["Renew Offer Type"] = labelencoder.fit_transform(insurance_4["Renew Offer Type"])'''
                                                         
                                                         
OHE = OneHotEncoder()
cols = ['Sales Channel',  'Location Code']

encoded_cols = OHE.fit_transform(insurance_2[cols])

# Create a dataframe from the encoded columns
encoded_df = pd.DataFrame.sparse.from_spmatrix(encoded_cols, columns=OHE.get_feature_names_out(cols))

# Concatenate the encoded dataframe with the original dataframe
insurance_3 = pd.concat([insurance_2.drop(cols, axis=1), encoded_df], axis=1)
insurance_3.info()

#For modeling, our data must be scaled, use min max scalr
cols_1 = list(num_col)

print(cols_1)

# Create an instance of MinMaxScaler
scale = MinMaxScaler()

# Fit and transform the numerical columns using the scaler

insurance_3[cols_1] = pd.DataFrame(scale.fit_transform(insurance_3[cols_1]), columns=cols_1)


#apply agglomerative clsutering
#First, we make a dendrogram to decide number of clsuters
plt.figure(1, figsize = (16, 8))
tree_plot = dendrogram(linkage(insurance_3, method  = "ward"))

plt.title('Hierarchical Clustering Dendrogram')
plt.xlabel('Index')
plt.ylabel('Euclidean distance')
plt.show()
#It seems to be 10 clsuters will be good

hc1 = AgglomerativeClustering(n_clusters = 10, affinity = 'euclidean', linkage = 'ward')
aggmodel_1 = hc1.fit(insurance_3) 
# # Clusters Evaluation
metrics.silhouette_score(insurance_3, hc1.labels_) #0.5871
#Silhouette score is very close but we need 0.6 

#Cluster Evaluation, we use clusteval to see where silhouette score is max
ce = clusteval(evaluate = 'silhouette', min_clust=2, max_clust= 25)
df_array = np.array(insurance_3)
# Fit
ce.fit(df_array)
# Plot
ce.plot()
#best clsuter number = 12

#Again, we check with 12 clsuters
hc2 = AgglomerativeClustering(n_clusters = 12, affinity = 'euclidean', linkage = 'ward')
aggmodel_2 = hc2.fit(insurance_3) 
# # Clusters Evaluation
metrics.silhouette_score(insurance_3, hc2.labels_) #0.6267
cluster_labels = pd.Series(hc2.labels_)
#This is our best model, we can start predict for dataset
insurance_3 = hc2.fit_predict(insurance_3)
#we got the labels for each column, lets concat with our dataset

final_insurance = pd.concat([insurance, cluster_labels], axis =1)
final_insurance = final_insurance.rename(columns = {0:'cluster'})
final_insurance.plot.scatter(x=cols_1[0], y=cols_1[1], c='cluster', colormap='viridis')


numerical_cols = final_insurance.select_dtypes(include=['int64', 'float64']).columns

sns.pairplot(data=final_insurance[numerical_cols], hue='cluster', diag_kind='hist', palette='viridis')

#Conclussion
#1) More number of complains is reducing CLTV, one need to resolve those
#2) People with high CLTV has 2 policies
#3)customers with high CLTV value had last claim more than 2 years ago, they need to be retained


categorical_cols = insurance.select_dtypes(include=['object']).columns

for col in categorical_cols:
    plt.figure()
    sns.countplot(x=col, hue='cluster', data=insurance, palette='viridis')
    plt.title(col)
    plt.show()

#Customers with high CLTV values said no in last campaign, they are employed or unemployed
#High CLTV customers belong to suburban area anf the also bought from agent
#The online channel is not going much good
#People buy mostly for four-door medsize car 

